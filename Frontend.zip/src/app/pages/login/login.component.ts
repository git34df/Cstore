import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth.service';
import { jwtDecode } from 'jwt-decode';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,RouterLink], // 👈 importante
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  loginForm: FormGroup; // 👈 antes faltaba esto
  loading = false; // 👈 y esto
  errorMsg = ''; // 👈 y esto también

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
    });
  }

  onSubmit(): void {
    if (this.loginForm.invalid) return;
    this.loading = true;

    this.authService.login(this.loginForm.value).subscribe({
      next: (token: string) => {
        console.log('✅ Token recibido:', token);
        this.loading = false;
        this.router.navigate(['/admin']); // o /user según corresponda
      },
      error: (err) => {
        console.error('❌ Error en login:', err);
        this.errorMsg = 'Credenciales incorrectas o servidor no disponible.';
        this.loading = false;
      },
    });
  }
}
