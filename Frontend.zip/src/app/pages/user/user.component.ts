import { Component } from '@angular/core';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss']
})
export class UserComponent {
  user = JSON.parse(localStorage.getItem('usuario') || '{}');

  logout() {
    localStorage.clear();
    window.location.href = '/login';
  }
}
