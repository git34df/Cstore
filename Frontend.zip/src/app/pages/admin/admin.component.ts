import { Component, OnInit } from '@angular/core';
import { jwtDecode } from 'jwt-decode';
import { TokenService } from '../../core/services/token.service';
import { DashboardService } from '../../core/services/dashboard.service';
import { Router, RouterLink } from '@angular/router';
import { UpperCasePipe, SlicePipe } from '@angular/common'; 

@Component({
  selector: 'app-admin',
  imports: [RouterLink, UpperCasePipe, SlicePipe],
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  user: any;
  nombreUsuario: string = '';
  inicialesUsuario: string = '';

  totalCategorias: number = 0;
  totalProductos: number = 0;
  totalFacturas: number = 0;

  constructor(
    private tokenService: TokenService,
    private dashboardService: DashboardService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Token
    const token = this.tokenService.getToken();
    if (token) {
      try {
        this.user = jwtDecode(token);
        const raw = this.user?.nombre ?? this.user?.name ?? this.user?.sub ?? '';
        this.nombreUsuario = raw.includes('@') ? raw.split('@')[0] : raw;
        this.inicialesUsuario = this.nombreUsuario.slice(0, 2).toUpperCase();
      } catch (err) {
        console.error('Error al decodificar token:', err);
      }
    }

    // Métricas reales desde el backend
    this.dashboardService.getMetrics().subscribe({
      next: (res) => {
        this.totalCategorias = res.categoria   || 0;
        this.totalProductos  = res.producto    || 0;
        this.totalFacturas   = res.Facturas    || 0;
      },
      error: (err) => {
        console.error('Error al obtener métricas:', err);
      }
    });
  }

  goToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}