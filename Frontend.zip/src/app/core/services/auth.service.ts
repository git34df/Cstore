import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { TokenService } from './token.service';
import { environment } from '../../enviroments/enviroment';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = `${environment.apiUrl}/usuario`;

  constructor(private http: HttpClient, private tokenService: TokenService) {}

  // 🔹 LOGIN
  login(credentials: { email: string; password: string }): Observable<any> {
    const body = {
      email: credentials.email,
      password: credentials.password,
    };

    return this.http.post(`${this.apiUrl}/Login`, body, { responseType: 'text' }).pipe(
      tap((token: string) => {
        if (token && typeof token === 'string') {
          this.tokenService.saveToken(token);
        } else {
          console.error('⚠️ Token inválido o vacío:', token);
        }
      })
    );
  }

  // 🔹 SIGNUP (registro de usuario)
  signup(data: {
    nombre: string;
    numerocontacto: string;
    email: string;
    contraseña: string;
  }): Observable<any> {
    return this.http.post(`${this.apiUrl}/signup`, data, { responseType: 'text' });
  }

  changePassword(data: { oldPassword: string; newPassword: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/ChangePassword`, data);
  }

  // 🔹 OLVIDAR CONTRASEÑA
  forgotPassword(email: string) {
    return this.http.post(
      `${this.apiUrl}/ForgotPassword`,
      { email },
      { responseType: 'text' }
    );
  }

  // 🔹 VALIDAR SESIÓN
  isLoggedIn(): boolean {
    return !!localStorage.getItem('token');
  }

  // 🔹 OBTENER ROL (si guardas usuario en localStorage)
  getUserRole(): string {
    const user = localStorage.getItem('usuario');
    return user ? JSON.parse(user).role : '';
  }

  // 🔹 CERRAR SESIÓN
  logout(): void {
    this.tokenService.removeToken();
  }

  // 🔹 VERIFICAR AUTENTICACIÓN
  isAuthenticated(): boolean {
    return !!this.tokenService.getToken();
  }
}
