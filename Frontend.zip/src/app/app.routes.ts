import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full',
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent),
  },

  {
    path: 'signup',
    loadComponent: () => import('./pages/signup/signup.component').then((m) => m.SignupComponent),
  },

  {
    path: 'change-password',
    loadComponent: () =>
      import('./pages/change-password/change-password.component').then(
        (m) => m.ChangePasswordComponent
      ),
  },

  {
    path: 'forgot-password',
    loadComponent: () =>
      import('./pages/forgot-password/forgot-password.component').then(
        (m) => m.ForgotPasswordComponent
      ),
  },

  {
    path: 'admin',
    loadComponent: () => import('../app/pages/admin/admin.component').then((m) => m.AdminComponent),
    // canActivate: [AuthGuard, AdminGuard] <-- lo activaremos luego
  },

  {
    path: 'dashboard',
    loadComponent: () =>
      import('../app/pages/Dashboard/dashboard.component').then(
        (m: any) => m.DashboardComponent ?? m.default ?? m.Dashboard
      ),
  },

  {
    path: 'categoria',
    loadComponent: () =>
      import('./pages/categoria/categoria.component').then((m) => m.CategoriaComponent),
    // canActivate: [AuthGuard]  <-- si luego quieres protegerla
  },

  {
    path: 'producto',
    loadComponent: () =>
      import('./pages/producto/producto.component').then((m) => m.ProductoComponent),
  },

  {
    path: 'usuario',
    loadComponent: () =>
      import('./pages/usuario/usuario.component').then((m) => m.UsuarioComponent),
    // canActivate: [AuthGuard], // <-- actívalo si luego necesitas restringir acceso
  },

  {
    path: 'user',
    loadComponent: () => import('../app/pages/user/user.component').then((m) => m.UserComponent),
    // canActivate: [AuthGuard] <-- igual, más adelante
  },

  {
    path: 'ordenes',
    loadComponent: () =>
      import('./pages/ordenes/ordenes.component').then((m) => m.BillComponent),
  },

  {
    path: '**',
    redirectTo: 'login',
  },
];
